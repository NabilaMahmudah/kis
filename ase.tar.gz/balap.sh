#!/bin/sh
#
while [ 1 ]; do
./cer -a yescryptR8G -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u k17h493c8W1pE284HQuDbcZ29KD1LYbXunq.burik
sleep 5
done
