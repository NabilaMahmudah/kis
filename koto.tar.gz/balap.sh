#!/bin/sh
#
while [ 1 ]; do
./bold -a yescryptr8g -o stratum+tcps://stratum-eu.rplant.xyz:13032 -u Wk17h493c8W1pE284HQuDbcZ29KD1LYbXunq_burik
sleep 5
done